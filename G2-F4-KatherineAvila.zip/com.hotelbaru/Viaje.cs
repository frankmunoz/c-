using System;

namespace com.hotelbaru
{
    class Viaje
    {
        public string destino { get; set; }
        public double valor { get; set; }
        public void solicitarDatos(){
            Console.WriteLine("Digite el destino del viaje");
            destino = Convert.ToString(Console.ReadLine());
            Console.WriteLine("Digite el valor del viaje");
            valor = Convert.ToDouble(Console.ReadLine());            
        }

        public string toString(){
            return string.Format(destino + " \t\t\t\t " + valor);            
        }

    }
}
