using System;

namespace com.hotelbaru
{
    class Cliente
    {
        public string id { get; set; }
        public string nombre { get; set; }
        public string habitacion { get; set; }
        public void solicitarDatos(){
            Console.WriteLine("Digite la identificación del cliente");
            id = Convert.ToString(Console.ReadLine());
            Console.WriteLine("Digite el nombre del cliente");
            nombre = Convert.ToString(Console.ReadLine());
            Console.WriteLine("Digite el número de habitación del cliente");
            habitacion = Convert.ToString(Console.ReadLine());
        }

        public string toString(){
            return string.Format(id + " \t\t\t\t " + nombre + " \t\t\t\t " + habitacion);            
        }

    }
}
