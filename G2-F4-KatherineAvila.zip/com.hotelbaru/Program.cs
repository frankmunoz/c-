﻿using System;

namespace com.hotelbaru
{

    class Program
    {
        Cliente[] clientes;
        Viaje[] viajes;
        
        static void Main(string[] args)
        {
            int opcionElegida = 0;
            int contadorCliente = 0;
            int contadorViaje = 0;
            Program hotelBaru = new Program();

            hotelBaru.clientes = new Cliente[0];
            hotelBaru.viajes = new Viaje[0];

            Console.Clear();
            hotelBaru.imprimirCreditos();

            while (opcionElegida != 5){
                try{

                    opcionElegida = hotelBaru.imprimirMenuPrincipal();                        

                    switch(opcionElegida){
                        case 1:
                            Console.WriteLine("Su selección: 1. Registrar Cliente\n");
                            Array.Resize(ref hotelBaru.clientes, hotelBaru.clientes.Length + 1);
                            hotelBaru.clientes[contadorCliente] = hotelBaru.registrarCliente();
                            contadorCliente++;
                            hotelBaru.imprimirCreditos();
                        break;
                        case 2:
                            Console.WriteLine("Su selección: 2. Registrar Viaje\n");
                            Array.Resize(ref hotelBaru.viajes, hotelBaru.viajes.Length + 1);
                            hotelBaru.viajes[contadorViaje] = hotelBaru.registrarViaje();
                            contadorViaje++;
                            hotelBaru.imprimirCreditos();
                        break;
                        case 3:
                            hotelBaru.imprimirCreditos();
                            Console.WriteLine("Su selección: 3. Imprimir directorio clientes\n");
                            hotelBaru.listarClientes();
                        break;
                        case 4:
                            hotelBaru.imprimirCreditos();
                            Console.WriteLine("Su selección: 4. Imprimir lista de viaje\n");
                            hotelBaru.listarViajes();
                        break;
                        case 5:
                            hotelBaru.imprimirSalida();  
                        break;
                        default:
                            Console.WriteLine("Opción no existe, por favor seleccione un número válido indicado en las opciones");
                        break;
                    }
                }catch (Exception e){
                    Console.WriteLine($"La opción seleccionada no es válida " + e.ToString());
                }
            }
        }      

        public Cliente registrarCliente(){
            Cliente cliente = new Cliente();
            cliente.solicitarDatos();
            return cliente;
        }
        public void listarClientes(){
            Console.WriteLine("{0} Clientes Registrados ", clientes.Length);

            Console.WriteLine("\nId \t\t\t\t Nombre \t\t\t\t Habitación " );
            foreach(Cliente cliente in clientes){
                Console.WriteLine(cliente.toString());
            }
        }

        public Viaje registrarViaje(){
            Viaje viaje = new Viaje();
            viaje.solicitarDatos();
            return viaje;

        }
        public void listarViajes(){
            Console.WriteLine("{0} Viajes Registrados ", viajes.Length);
            Console.WriteLine("\nDestino \t\t\t\t Valor" );

            foreach(Viaje viaje in viajes){
                Console.WriteLine(viaje.toString());
            }
        }        

        public void imprimirCreditos(){
            Console.Write("\n****************************************************************************");
            Console.Write("\n,--.  ,--.         ,--.         ,--.    ,-----.                          ");
            Console.Write("\n|  '--'  | ,---. ,-'  '-. ,---. |  |    |  |) /_  ,--,--.,--.--.,--.,--. ");
            Console.Write("\n|  .--.  || .-. |'-.  .-'| .-. :|  |    |  .-.  \' ,-.  ||  .--'|  ||  | ");
            Console.Write("\n|  |  |  |' '-' '  |  |  |  --. |  |    |  '--' /\' '-'  ||  |   '  ''  ' ");
            Console.Write("\n`--'  `--' `---'   `--'   `----'`--'    `------'  `--`--'`--'    `----'  ");
            Console.Write("\n                                                 Por: Johana Katherine Ávila");
            Console.Write("\n****************************************************************************");
            Console.Write("\n\nPrograma que permite administrar clientes y viajes del Hotel Baru\n\n");
        }

        public void imprimirSalida(){
            Console.Clear();
            Console.Write("\n ,----.                        ,--.                                                                  ,---.              ,--.                              ");
            Console.Write("\n'  .-./   ,--.--. ,--,--. ,---.`--' ,--,--. ,---.      ,---.  ,---. ,--.--.     ,---. ,--.--. ,---. /  .-' ,---. ,--.--.`--',--.--.,--,--,  ,---.  ,---.  ");
            Console.Write("\n|  | .---.|  .--'' ,-.  || .--',--.' ,-.  |(  .-'     | .-. || .-. ||  .--'    | .-. ||  .--'| .-. :|  `-,| .-. :|  .--',--.|  .--'|      \'| .-. |(  .-'  ");
            Console.Write("\n'  '--'  ||  |   \' '-'  |\' `--.|  |\' '-'  |.-'  `)    | '-' '' '-' '|  |       | '-' '|  |   \'   --.|  .-'\'   --.|  |   |  ||  |   |  ||  |' '-' '.-'  `) ");
             Console.Write("\n`------' `--'    `--`--' `---'`--' `--`--'`----'      |  |-'  `---' `--'       |  |-' `--'    `----'`--'   `----'`--'   `--'`--'   `--''--' `---' `----'  ");
            Console.Write("\n                                                       `--'                     `--'                                                                       \n");
        }
        public int imprimirMenuPrincipal(){
            Console.Write("\nSeleccione una opción: ");
            Console.Write("\n[1] Registrar Cliente ");
            Console.Write("\n[2] Registrar Viaje ");
            Console.Write("\n[3] Imprimir directorio clientes");
            Console.Write("\n[4] Imprimir lista de viajes");
            Console.Write("\n[5] Salir \n");
            return Convert.ToInt16(Console.ReadLine());
        }

    }
        
}
